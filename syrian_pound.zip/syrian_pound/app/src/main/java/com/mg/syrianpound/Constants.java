package com.mg.syrianpound;

public interface Constants {
    public static final  double dolarChange=10;
    public static final String API_KEY = "mzwgqysokwpceiqsrokmochunydkytcl";
}
