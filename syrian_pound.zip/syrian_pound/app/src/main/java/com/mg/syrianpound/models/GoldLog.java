package com.mg.syrianpound.models;

public class GoldLog {
    private  double gold_price;

    public GoldLog(double gold_price) {
        this.gold_price = gold_price;
    }

    public double getGold_price() {
        return gold_price;
    }
}
